import os
import re
import uuid
import json
import time
import logging
from typing import List, Dict, Any
import requests
from flask import Flask, request, jsonify, send_from_directory, abort

# -----------------------------
# Config
# -----------------------------
# If running via docker-compose, this will be http://ollama:11434
# If running Flask alone on your host, use http://localhost:11434
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3")

# Simple regex for test case generation trigger (mimics Java's TEST_CASE_GENERATION_PATTERN idea)
TEST_CASE_REGEX = re.compile(r"^\s*(generate\s+test\s+cases?)\b", re.I)

# In-memory session store: { session_id: [ {q, a, ts}, ... ] }
SESSIONS: Dict[str, List[Dict[str, Any]]] = {}

# Flask App
app = Flask(__name__)

# Logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("chatbot")

# -----------------------------
# Helpers
# -----------------------------
def create_or_get_session(session_id: str | None) -> str:
    """Create a new session if not provided; reuse if valid; else error."""
    if not session_id:
        new_id = str(uuid.uuid4())
        SESSIONS[new_id] = []
        return new_id
    if session_id not in SESSIONS:
        # If client sends an unknown sessionId, create a fresh one to be forgiving
        SESSIONS[session_id] = []
    return session_id

def prompt_security_check(question: str, prompt: str) -> bool:
    """
    Very basic security filter — expand as needed.
    Reject obvious destructive injection attempts similar to your Java security check.
    """
    risky = ["drop table", "delete from", "shutdown", "format c:", "rm -rf /", "curl http"]
    text = f"{question}\n{prompt}".lower()
    return not any(word in text for word in risky)

def build_prompt(question: str, context: List[Dict[str, Any]]) -> str:
    """
    Build a single prompt string for Ollama's /api/generate.
    We include recent Q/A as context.
    """
    header = (
        "You are a helpful, concise assistant. "
        "Use clear structure, bullet points where helpful, and markdown tables when asked."
    )

    # Include up to last 8 exchanges as context
    history_lines = []
    for turn in context[-8:]:
        q = turn.get("q", "").strip()
        a = turn.get("a", "").strip()
        if q:
            history_lines.append(f"User: {q}")
        if a:
            history_lines.append(f"Assistant: {a}")

    history_block = "\n".join(history_lines) if history_lines else "No prior context."

    # Test case path
    if TEST_CASE_REGEX.match(question or ""):
        # Keep this similar to how QA/test case generation might work in your Java code
        body = (
            "The user is asking for TEST CASE GENERATION.\n"
            "Create comprehensive, high-quality test cases in a markdown table with columns:\n"
            "ID | Title | Preconditions | Steps | Expected Result | Priority\n"
            "Make test cases precise and executable. Use numbering for IDs.\n"
            f"User instruction: {question}\n"
        )
    else:
        body = (
            "The user asks a normal question. Answer directly and helpfully.\n"
            f"User question: {question}\n"
        )

    prompt = f"{header}\n\nContext:\n{history_block}\n\nTask:\n{body}"
    return prompt

def call_ollama_generate(prompt: str) -> str:
    """
    Call the Ollama /api/generate endpoint (non-streaming) and return the final 'response' text.
    Includes retry logic in case Ollama isn't fully ready yet.
    """
    url = f"{OLLAMA_BASE_URL}/api/generate"
    payload = {
        "model": OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {
            # Tweak as needed
            "temperature": 0.3,
            "num_predict": 700
        }
    }

    # Retry a few times in case Ollama is initializing or the model isn't loaded yet
    last_err = None
    for attempt in range(5):
        try:
            resp = requests.post(url, json=payload, timeout=120)
            if resp.status_code == 200:
                data = resp.json()
                # Ollama returns {"model": "...", "created_at": "...", "response": "..."}
                return data.get("response", "").strip() or "⚠️ Model returned an empty response."
            else:
                last_err = f"{resp.status_code} {resp.text}"
        except Exception as e:
            last_err = str(e)
        time.sleep(1 + attempt)  # backoff

    raise RuntimeError(f"Ollama API error after retries: {last_err}")

# -----------------------------
# Routes
# -----------------------------
@app.route("/", methods=["GET"])
def home():
    # Serve the UI from the same host/port
    return send_from_directory(".", "index.html")

@app.route("/health", methods=["GET"])
def health():
    # Quick health check endpoint
    try:
        r = requests.get(f"{OLLAMA_BASE_URL}/api/tags", timeout=5)
        ok = r.status_code == 200
        return jsonify({"status": "ok" if ok else "degraded", "ollama_status_code": r.status_code}), (200 if ok else 503)
    except Exception as e:
        return jsonify({"status": "down", "error": str(e)}), 503

@app.route("/chat", methods=["POST"])
def chat():
    """
    JSON body: { question: string, sessionId?: string }
    Returns: { answer, sessionId, message? }
    """
    if not request.is_json:
        return jsonify({"error": "Request must be JSON."}), 400
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    session_id = data.get("sessionId")

    if not question:
        return jsonify({"error": "Question is required."}), 400

    used_session_id = create_or_get_session(session_id)
    context = SESSIONS.get(used_session_id, [])

    # Build prompt depending on path
    prompt = build_prompt(question, context)

    # Security gate
    if not prompt_security_check(question, prompt):
        return jsonify({"error": "❌ Security check failed."}), 403

    try:
        answer = call_ollama_generate(prompt)
        # Save turn
        context.append({"q": question, "a": answer, "ts": int(time.time())})
        SESSIONS[used_session_id] = context
        resp = {
            "answer": answer,
            "sessionId": used_session_id
        }
        if not session_id:
            resp["message"] = f"New session created with ID {used_session_id}"
        return jsonify(resp), 200
    except Exception as e:
        logger.exception("Chat error")
        return jsonify({"error": f"Server error: {str(e)}"}), 500

# -----------------------------
# Entrypoint
# -----------------------------
if __name__ == "__main__":
    # Dev server; in Docker we run gunicorn
    app.run(host="0.0.0.0", port=5000, debug=True)
