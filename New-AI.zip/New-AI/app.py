import os
import uuid
import tempfile
from flask import Flask, request, jsonify, render_template, send_file
from werkzeug.utils import secure_filename
import faiss
import numpy as np
import pickle
from sentence_transformers import SentenceTransformer
import requests
import pandas as pd

# Config
UPLOADS_DIR = "uploads"
DATA_DIR = "data"
EMBED_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
DEFAULT_MODEL = os.getenv("OLLAMA_MODEL", "llama3.1")

os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)

app = Flask(__name__, template_folder="templates", static_folder="static")
embedder = SentenceTransformer(EMBED_MODEL)


# ---------- Helpers ----------
def chunk_text(text, chunk_size=500, overlap=50):
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        start += chunk_size - overlap
    return chunks


def embed_chunks(chunks):
    return embedder.encode(chunks, convert_to_numpy=True)


def save_vector_store(session_id, vectors, chunks):
    index = faiss.IndexFlatL2(vectors.shape[1])
    index.add(vectors)
    faiss.write_index(index, os.path.join(DATA_DIR, f"{session_id}.index"))
    with open(os.path.join(DATA_DIR, f"{session_id}.pkl"), "wb") as f:
        pickle.dump(chunks, f)


def load_vector_store(session_id):
    index = faiss.read_index(os.path.join(DATA_DIR, f"{session_id}.index"))
    with open(os.path.join(DATA_DIR, f"{session_id}.pkl"), "rb") as f:
        chunks = pickle.load(f)
    return index, chunks


def query_vector_store(session_id, question, top_k=5):
    index, chunks = load_vector_store(session_id)
    q_emb = embedder.encode([question], convert_to_numpy=True)
    D, I = index.search(q_emb, top_k)
    return [chunks[i] for i in I[0] if i < len(chunks)]


def ollama_chat(prompt, model=DEFAULT_MODEL):
    resp = requests.post(f"{OLLAMA_URL}/api/generate", json={
        "model": model,
        "prompt": prompt,
        "stream": False
    })
    return resp.json().get("response", "")


# ---------- Routes ----------
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    files = request.files.getlist("files[]")
    question = request.form.get("question")
    model = request.form.get("model", DEFAULT_MODEL)
    session_id = request.form.get("sessionId")

    chunks = []

    if files:
        session_id = str(uuid.uuid4())
        all_text = ""
        for file in files:
            filename = secure_filename(file.filename)
            path = os.path.join(UPLOADS_DIR, filename)
            file.save(path)
            with open(path, "r", errors="ignore") as f:
                all_text += f.read() + "\n"
        chunks = chunk_text(all_text)
        vectors = embed_chunks(chunks)
        save_vector_store(session_id, vectors, chunks)

    elif session_id:
        chunks = query_vector_store(session_id, question)

    if not chunks:
        return jsonify({"answer": "No context found.", "sessionId": session_id})

    context = "\n".join(chunks)
    prompt = f"Context:\n{context}\n\nQuestion: {question}\nAnswer:"
    answer = ollama_chat(prompt, model)

    return jsonify({"answer": answer, "sessionId": session_id})


@app.route("/generate-test-cases", methods=["POST"])
def generate_test_cases():
    files = request.files.getlist("files[]")
    model = request.form.get("model", DEFAULT_MODEL)
    session_id = request.form.get("sessionId")

    if files:
        session_id = str(uuid.uuid4())
        all_text = ""
        for file in files:
            filename = secure_filename(file.filename)
            path = os.path.join(UPLOADS_DIR, filename)
            file.save(path)
            with open(path, "r", errors="ignore") as f:
                all_text += f.read() + "\n"
        chunks = chunk_text(all_text)
        vectors = embed_chunks(chunks)
        save_vector_store(session_id, vectors, chunks)
    elif session_id:
        chunks = query_vector_store(session_id, "test cases")
    else:
        return jsonify({"error": "No input files or session ID"}), 400

    context = "\n".join(chunks)
    prompt = f"Context:\n{context}\n\nGenerate software test cases in a markdown table format."
    response = ollama_chat(prompt, model)

    # Parse into excel
    df = pd.DataFrame([x.split("|")[1:-1] for x in response.split("\n") if "|" in x])
    out = tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx")
    df.to_excel(out.name, index=False, header=False)

    return send_file(out.name, as_attachment=True, download_name="test_cases.xlsx")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
